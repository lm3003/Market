
import java.util.*;

//Honor Pledge:
//
//I pledge that I have neither given nor 
//received any help on this assignment.
//
//lmodi

/**
 * 
 */
public class MarketModel {

    /**
     * Default constructor
     */
    public MarketModel() {
    }

    /**
     * 
     */
    public void marketModel() {
        // TODO implement here
    }

    /**
     * 
     */
    public void getItem() {
        // TODO implement here
    }

}