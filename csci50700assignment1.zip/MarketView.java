
import java.util.*;

//Honor Pledge:
//
//I pledge that I have neither given nor 
//received any help on this assignment.
//
//lmodi

public class MarketView {

    /**
     * Default constructor
     */
    public MarketView() {
    }

    /**
     * 
     */
    public void marketView() {
        // TODO implement here
    }

    /**
     * 
     */
    public void displayItem() {
        // TODO implement here
    }

}