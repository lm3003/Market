
import java.util.*;

//Honor Pledge:
//
//I pledge that I have neither given nor 
//received any help on this assignment.
//
//lmodi

public class Customer {

    /**
     * Default constructor
     */
    public Customer() {
    }

    /**
     * 
     */
    int id;

    /**
     * 
     */
    String userName;

    /**
     * 
     */
    String password;

    /**
     * 
     */
    String fullName;

    /**
     * 
     */
    String address;

    /**
     * 
     */
    String email;

    /**
     * 
     */
    int shoppingCartId;

    /**
     * 
     */
    String creditCardInfo;







    /**
     * 
     */
    public void browse() {
        // TODO implement here
    }

    /**
     * 
     */
    public void purchaseItem() {
        // TODO implement here
    }

    /**
     * 
     */
    public void registerAccount() {
        // TODO implement here
    }

    /**
     * 
     */
    public void addToCart() {
        // TODO implement here
    }

}