
import java.util.*;

//Honor Pledge:
//
//I pledge that I have neither given nor 
//received any help on this assignment.
//
//lmodi

public class Administrator {

    /**
     * Default constructor
     */
    public Administrator() {
    }

    /**
     * 
     */
    int id;

    /**
     * 
     */
    String userName;

    /**
     * 
     */
    String password;

    /**
     * 
     */
    String fullName;

    /**
     * 
     */
    String email;



    /**
     * 
     */
    public void addItem() {
        // TODO implement here
    }

    /**
     * 
     */
    public void updateItem() {
        // TODO implement here
    }

    /**
     * 
     */
    public void deleteItem() {
        // TODO implement here
    }

    /**
     * 
     */
    public void addAdmin() {
        // TODO implement here
    }

    /**
     * 
     */
    public void addCustomerAccount() {
        // TODO implement here
    }

    /**
     * 
     */
    public void removeCustomerAccount() {
        // TODO implement here
    }

}