
import java.util.*;

//Honor Pledge:
//
//I pledge that I have neither given nor 
//received any help on this assignment.
//
//lmodi

public class ShoppingCart {

    /**
     * Default constructor
     */
    public ShoppingCart() {
    }

    /**
     * 
     */
    private String user;

    /**
     * 
     */
    int id;

    /**
     * 
     */
    int customerId;

    /**
     * 
     */
    int item;

    /**
     * 
     */
    int quantity;




}