
import java.util.*;

//Honor Pledge:
//
//I pledge that I have neither given nor 
//received any help on this assignment.
//
//lmodi

public class Item {

    /**
     * Default constructor
     */
    public Item() {
    }

    /**
     * 
     */
    int id;

    /**
     * 
     */
    String name;

    /**
     * 
     */
    String description;

    /**
     * 
     */
    String type;

    /**
     * 
     */
    float price;

    /**
     * 
     */
    int quantity;





}